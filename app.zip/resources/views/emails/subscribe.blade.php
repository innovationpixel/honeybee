<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8" />
    </head>
    <body>
        <h2>Enquiry Details</h2>
        <p> Email : {{ $data['sub_email'] }}</p>
    </body>
</html>