<!DOCTYPE html>
<html lang="en-US">
    <head>
        <meta charset="utf-8" />
    </head>
    <body>
        <h2>Enquiry Details</h2>
        <p> First Name : {{ $data['first_name'] }}</p>
        <p> Last Name : {{ $data['last_name'] }}</p>
        <p> Email : {{ $data['email'] }}</p>
        <p> Phone : {{ $data['phone'] }}</p>
        <p> Message : {{ $data['message'] }}</p>
    </body>
</html>